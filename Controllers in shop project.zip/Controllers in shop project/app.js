//const http = require('http'); //importing http module

//Parsing incoming requests with routing using middlewares

const express = require('express'); // importing express js 
const bodyParser= require('body-parser'); // importing bodyparser  
const path= require('path');

const app = express(); //storing express in app varibale
const adminRoute= require('./routes/admin'); // Importing admin routes
const shopRoute= require('./routes/shop'); // Importing shop routes
const contactRoute= require('./routes/contact'); // Importing contact routes

app.use(bodyParser.urlencoded({extended: false})); // Parsing URL-encoded request body
app.use(express.static(path.join(__dirname,'public'))); // Serve static files from the public directory

app.use('/admin', adminRoute);
app.use(shopRoute);
app.use(contactRoute);

app.use((req, res, next)=>{  // Sending 404 Error page
    res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
})

app.listen(3000);  // listens for 3000 port  
