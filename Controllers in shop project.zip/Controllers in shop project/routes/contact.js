const express= require('express'); // Importing Express.js

const router= express.Router(); // Creating an Express router

const {contact, success} = require('../controllers/admin_&_Shop');

router.get('/contact_us', contact);

router.post('/success', success);

module.exports =router;