// Importing required modules

const express= require('express');
const router= express.Router();

const path= require('path');
const rootDir= require('../util/path');
const { admin, addProd } = require('../controllers/admin_&_Shop');

router.get('/add-products', admin);

router.post('/add-product', addProd);

module.exports= router;