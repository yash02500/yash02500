const express= require('express'); // Importing Express.js

const router= express.Router(); // Creating an Express router

const {shop} = require('../controllers/admin_&_Shop');

const path= require('path'); // Importing the path module 
const rootDir= require('../util/path'); // Importing a custom module to get the root directory

router.get('/', shop);

module.exports =router;