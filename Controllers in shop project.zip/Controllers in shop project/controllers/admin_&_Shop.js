const path= require('path'); // Importing the path module 
const rootDir= require('../util/path'); // Importing a custom module to get the root directory


const admin= (req, res, next) => { // Handling GET requests to the '/add-products' path
    res.sendFile(path.join(rootDir, 'views', 'add-product.html')); // Sending add-product.html form   
}

const addProd= (req, res, next) => { // Handling POST requests to the '/add-product' path
    console.log(req.body);
    res.redirect('/');  // Redirecting to the root path ('/') after processing the form submission
}

const shop= (req, res, next) => { // GET requests to the root path ('/')
    res.sendFile(path.join(rootDir, 'views', 'shop.html')); //  Sending the 'shop.html' file in response
}

const contact= (req, res, next) => {  // Route for contact us page
    res.sendFile(path.join(rootDir, 'views', 'contactUs.html'));  // Sending conatctus.html form   
}

const success= (req, res, next) => { //  Handling POST requests to the '/success' path
    console.log(req.body);
    res.sendFile(path.join(rootDir, 'views','success.html'));  // Sending html form   
}

module.exports={admin, addProd, shop, contact, success};