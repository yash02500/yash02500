const axios = require('axios');
var userForm = document.getElementById('expForm');
var expAmount = document.getElementById('amt');
var expDescription = document.getElementById('dec');
var expCategory = document.getElementById('choose');
var ulList = document.createElement('ul');
userForm.addEventListener('submit', submitForm);

// ...

async function submitForm() {
  const amount = document.getElementById('amt').value;
  const description = document.getElementById('dec').value;
  const expCategory = document.getElementById('choose').value;

  try {
    const response = await axios.post('/admin/expenses', { amount, description, expCategory });
    document.getElementById('amt').value = '';
    document.getElementById('dec').value = '';
    getUsers();
  } catch (error) {
    console.error(error);
  }
}

// ...

async function getUsers() {
  try {
    const response = await axios.get('/admin/expenses');
    const userList = document.getElementById('expList');

    // Clear existing data
    userList.innerHTML = '';

    // Display the users in the table
    response.data.forEach(expense => {
      const row = document.createElement('li');
      row.innerHTML = `
        <span>${expense.amount} - ${expense.description} - ${expense.expCategory}</span>
        <button onclick="deleteExpense(${expense.id})">Delete</button>
        <button onclick="editExpense(${expense.id})">Edit</button>
      `;
      userList.appendChild(row);
    });
  } catch (error) {
    console.error(error);
  }
}

// Function to delete an expense
async function deleteExpense(expenseId) {
  try {
    await axios.delete(`/admin/expenses/${expenseId}`);
    getUsers();
  } catch (error) {
    console.error(error);
  }
}


async function editExpense(expenseId) {
  try {
    // Fetch the existing expense data
    const existingExpense = await axios.get(`/admin/expenses/${expenseId}`);
    const { amount, description, expCategory } = existingExpense.data;

    // Set the values of the input fields to the expense's data
    document.getElementById('amt').value = amount;
    document.getElementById('dec').value = description;
    document.getElementById('choose').value = expCategory;

    // Delete the existing expense
    await axios.delete(`/admin/expenses/${expenseId}`);
    getUsers();
  } catch (error) {
    console.error(error);
  }
}


// Initial load of expenses
getUsers();
