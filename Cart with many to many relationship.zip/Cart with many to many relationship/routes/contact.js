const express= require('express'); // Importing Express.js

const router= express.Router(); // Creating an Express router

const productsController = require('../controllers/products');

router.get('/contact_us', productsController.getContact);

router.post('/success', productsController.getSuccess);

module.exports = router;
