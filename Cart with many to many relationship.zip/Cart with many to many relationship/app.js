// Required modules
const path = require('path'); // Module for handling file paths
const express = require('express'); // Web framework for Node.js
const bodyParser = require('body-parser'); // Middleware to parse incoming request bodies

// Controllers
const errorController = require('./controllers/error'); // Importing error handling controller

// Import db
const sequelize= require('./util/database');

// Import product model
const Product= require('./models/product');

// Import user model
const User= require('./models/user');

// Import cart model
const Cart = require('./models/cart');
const CartItem = require('./models/cart-item');

// Initialize express app
const app = express(); // Creating an instance of Express

// Setting up the view engine and views directory
app.set('view engine', 'ejs'); // Setting EJS as the view engine
app.set('views', 'views'); // Setting the views directory

// Routes
const adminRoutes = require('./routes/admin'); // Importing admin routes
const shopRoutes = require('./routes/shop'); // Importing shop routes

// Middleware
app.use(bodyParser.urlencoded({ extended: false })); // Parsing URL-encoded bodies
app.use(express.static(path.join(__dirname, 'public'))); // Serving static files

app.use((req, res, next)=>{
    User.findByPk(1)
    .then(user =>{
        req.user= user;
        next();
    })
    .catch(err=> console.log(err));
});

// Routing
app.use('/admin', adminRoutes); // Mounting admin routes
app.use(shopRoutes); // Mounting shop routes

// Error Handling
app.use(errorController.get404); // Handling 404 errors

// Relations between entities
Product.belongsTo(User, {constraints: true, onDelete: 'CASCADE'});
User.hasMany(Product);
User.hasOne(Cart);
Cart.belongsTo(User);
Cart.belongsToMany(Product, { through: CartItem });
Product.belongsToMany(Cart, { through: CartItem });

// sequelize.sync({force: true})
sequelize.sync()
    .then(result=> {
    User.findByPk(1);
    console.log(result);
})

.then(user=> {
    if(!user){
       return User.create({name: 'Yash', email: 'demo@gmail.com'});
    }
    return user;
})

.then(user =>{
    console.log(user);
    return user.createCart();
})

// .then(cart => {
//     app.listen(3000);
//   })

.catch(err=> {
    console.log(err); // Server listens on port 3000
});


app.listen(3000);