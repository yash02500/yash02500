const Product = require('../models/product'); // Importing the Product model

// Render page for adding a product
exports.getAddProduct = (req, res, next) => {
  res.render('admin/edit-product', {
    pageTitle: 'Add Product',
    path: '/admin/add-product',
    editing: false
  });
};

// Process the addition of a new product
exports.postAddProduct = (req, res, next) => {
  // Extracting product details from the request
  const title = req.body.title;
  const imageUrl = req.body.imageUrl;
  const price = req.body.price;
  const description = req.body.description;
  req.user.createProduct({
    title: title,
    price: price,
    imageUrl: imageUrl,
    description: description,
  })
  .then(result=> {
    console.log('Created Product');
    res.redirect('/admin/products');
  }) 
  .catch(err=> {
    console.log(err);
  }); 
};

// Render the page for editing a product
exports.getEditProduct = (req, res, next) => {
  const editMode = req.query.edit;
  if (!editMode) {
    return res.redirect('/'); // Redirect if not in edit mode
  }
  const prodId = req.params.productId;
  req.user.getProducts({where: {id: prodId}})
  //Product.findByPk(prodId)
  .then(products => {
    const product= products[0];
    if (!product) {
      return res.redirect('/'); // Redirect if product not found
    }
    // Render the edit-product page with product details
    res.render('admin/edit-product', {
      pageTitle: 'Edit Product',
      path: '/admin/edit-product',
      editing: editMode,
      product: product
    });
  })
  .catch(err=> console.log(err));
};

// Process the edited product details
exports.postEditProduct = (req, res, next) => {
  const prodId = req.body.productId;
  const updatedTitle = req.body.title;
  const updatedPrice = req.body.price;
  const updatedImageUrl = req.body.imageUrl;
  const updatedDesc = req.body.description;
  // Save the updated product
  Product.findByPk(prodId)
  .then(product => {
    product.title= updatedTitle;
    product.price= updatedPrice;
    product.description= updatedDesc;
    product.imageUrl= updatedImageUrl;
    return product.save();
  })
  .then(result => {
    console.log('UPDATED PRODUCT');
    res.redirect('/admin/products'); // Redirect to admin products page
  })
  .catch(err => console.log(err));
};

// Render the admin products page
exports.getProducts = (req, res, next) => {
  req.user.getProducts()
  .then(products => {
    res.render('admin/products', {
      prods: products, // Pass fetched products to render
      pageTitle: 'Admin Products',
      path: '/admin/products'
    });
  })
  .catch(err=> console.log(err));
};

// Process the deletion of a product
exports.postDeleteProduct = (req, res, next) => {
  const prodId = req.body.productId;
  Product.findByPk(prodId) // Delete the product
  .then(product=> {
    return product.destroy();
  })
  .then(result=> {
    console.log('DESTROYED PRODUCT');
    res.redirect('/admin/products'); // Redirect to admin products page
  })
  .catch(err => console.log(err));
};
