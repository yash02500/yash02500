const Product = require('../models/product'); // Importing the Product model
const Cart = require('../models/cart'); // Importing the Cart model

// Render the 'All Products' page
exports.getProducts = (req, res, next) => {
  Product.findAll()
  .then(products=> {
    res.render('shop/product-list', {
      prods: products, // Pass fetched products to render
      pageTitle: 'All Products',
      path: '/products'
   });
  })
  .catch(err=> {
    console.log(err);
  });
};

// Render the 'Product Detail' page
exports.getProduct = (req, res, next) => {
  const prodId = req.params.productId;
  Product.findByPk(prodId)
  .then(product => {
    res.render('shop/product-detail', {
      product: product, // Pass the fetched product to render
      pageTitle: product.title,
      path: '/products'
    });
  })
  .catch(err=> console.log(err));
};

// Render the 'Shop' (Homepage) page
exports.getIndex = (req, res, next) => {
  Product.findAll()
  .then(products=> {
    res.render('shop/index', {
      prods: products, // Pass fetched products to render
      pageTitle: 'Shop',
      path: '/'
   });
  })
  .catch(err=> {
    console.log(err);
  });
};

// Render the 'Cart' page
exports.getCart = (req, res, next) => {
  req.user.getCart()
    .then(cart => {
      return cart
        .getProducts()
        .then(products => {
          res.render('shop/cart', {
            path: '/cart',
            pageTitle: 'Your Cart',
            products: products
          });
        })
        .catch(err => console.log(err));
    })
    .catch(err => console.log(err));
};


// Add a product to the cart
exports.postCart = (req, res, next) => {
  const prodId = req.body.productId;
  let fetchedCart;
  let newQuantity = 1;
  req.user
    .getCart()
    .then(cart => {
      fetchedCart = cart;
      return cart.getProducts({ where: { id: prodId } });
    })
    .then(products => {
      let product;
      if (products.length > 0) {
        product = products[0];
      }

      if (product) {
        const oldQuantity = product.cartItem.quantity;
        newQuantity = oldQuantity + 1;
        return product;
      }
      return Product.findById(prodId);
    })
    .then(product => {
      return fetchedCart.addProduct(product, {
        through: { quantity: newQuantity }
      });
    })
    .then(() => {
      res.redirect('/cart');  
    })
    .catch(err => console.log(err));
}


// Delete a product from the cart
exports.postCartDeleteProduct = (req, res, next) => {
  const prodId = req.body.productId;
  req.user
    .getCart()
    .then(cart => {
      return cart.getProducts({ where: { id: prodId } });
    })
    .then(products => {
      const product = products[0];
      return product.cartItem.destroy();
    })
    .then(result => {
      res.redirect('/cart');
    })
    .catch(err => console.log(err));
};

// Render the 'Orders' page
exports.getOrders = (req, res, next) => {
  res.render('shop/orders', {
    path: '/orders',
    pageTitle: 'Your Orders'
  });
};

// Render the 'Checkout' page
exports.getCheckout = (req, res, next) => {
  res.render('shop/checkout', {
    path: '/checkout',
    pageTitle: 'Checkout'
  });
};
