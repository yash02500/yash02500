const Product = require('../models/product'); // Importing the Product model

// Render page for adding a product
exports.getAddProduct = (req, res, next) => {
  res.render('admin/edit-product', {
    pageTitle: 'Add Product',
    path: '/admin/add-product',
    editing: false
  });
};

// Process the addition of a new product
exports.postAddProduct = (req, res, next) => {
  // Extracting product details from the request
  const title = req.body.title;
  const imageUrl = req.body.imageUrl;
  const price = req.body.price;
  const description = req.body.description;
  const product = new Product(null, title, imageUrl, description, price); // Creating a new Product instance
  product.save()
  .then(()=> {
    res.redirect('/'); // Redirect to the main page
  })
  .catch(err=> console.log(err)); 
};

// Render the page for editing a product
exports.getEditProduct = (req, res, next) => {
  const editMode = req.query.edit;
  if (!editMode) {
    return res.redirect('/'); // Redirect if not in edit mode
  }
  const prodId = req.params.productId;
  Product.findById(prodId, product => {
    if (!product) {
      return res.redirect('/'); // Redirect if product not found
    }
    // Render the edit-product page with product details
    res.render('admin/edit-product', {
      pageTitle: 'Edit Product',
      path: '/admin/edit-product',
      editing: editMode,
      product: product
    });
  });
};

// Process the edited product details
exports.postEditProduct = (req, res, next) => {
  const prodId = req.body.productId;
  const updatedTitle = req.body.title;
  const updatedPrice = req.body.price;
  const updatedImageUrl = req.body.imageUrl;
  const updatedDesc = req.body.description;
  const updatedProduct = new Product(prodId, updatedTitle, updatedImageUrl, updatedDesc, updatedPrice); // Create a Product instance with updated details
  updatedProduct.save(); // Save the updated product
  res.redirect('/admin/products'); // Redirect to admin products page
};

// Render the admin products page
exports.getProducts = (req, res, next) => {
  Product.fetchAll(products => {
    res.render('admin/products', {
      prods: products, // Pass fetched products to render
      pageTitle: 'Admin Products',
      path: '/admin/products'
    });
  });
};

// Process the deletion of a product
exports.postDeleteProduct = (req, res, next) => {
  const prodId = req.body.productId;
  Product.deleteById(prodId); // Delete the product
  res.redirect('/admin/products'); // Redirect to admin products page
};
