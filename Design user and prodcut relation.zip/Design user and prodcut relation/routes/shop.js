const path = require('path');

const express = require('express');

const shopController = require('../controllers/shop');

const router = express.Router();

router.get('/', shopController.getIndex); // GET request for the shop's index

router.get('/products', shopController.getProducts); // GET request for fetching products

router.get('/products/:productId', shopController.getProduct); // GET request to view a specific product

router.get('/cart', shopController.getCart); // GET request to view the shopping cart

router.post('/cart', shopController.postCart); // POST request to add items to the shopping cart

router.post('/cart-delete-item', shopController.postCartDeleteProduct); // POST request to delete items from the shopping cart

router.get('/orders', shopController.getOrders); // GET request to view orders

router.get('/checkout', shopController.getCheckout); // GET request for the checkout page

module.exports = router; 





