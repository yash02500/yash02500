const Product = require('../models/product'); // Importing the Product model
const Cart = require('../models/cart'); // Importing the Cart model

// Render the 'All Products' page
exports.getProducts = (req, res, next) => {
  Product.findAll()
  .then(products=> {
    res.render('shop/product-list', {
      prods: products, // Pass fetched products to render
      pageTitle: 'All Products',
      path: '/products'
   });
  })
  .catch(err=> {
    console.log(err);
  });
};

// Render the 'Product Detail' page
exports.getProduct = (req, res, next) => {
  const prodId = req.params.productId;
  Product.findByPk(prodId)
  .then(product => {
    res.render('shop/product-detail', {
      product: product, // Pass the fetched product to render
      pageTitle: product.title,
      path: '/products'
    });
  })
  .catch(err=> console.log(err));
};

// Render the 'Shop' (Homepage) page
exports.getIndex = (req, res, next) => {
  Product.findAll()
  .then(products=> {
    res.render('shop/index', {
      prods: products, // Pass fetched products to render
      pageTitle: 'Shop',
      path: '/'
   });
  })
  .catch(err=> {
    console.log(err);
  });
};

// Render the 'Cart' page
exports.getCart = (req, res, next) => {
  Cart.getCart(cart => {
    Product.fetchAll(products => {
      const cartProducts = [];
      for (product of products) {
        const cartProductData = cart.products.find(prod => prod.id === product.id);
        if (cartProductData) {
          cartProducts.push({ productData: product, qty: cartProductData.qty });
        }
      }
      res.render('shop/cart', {
        path: '/cart',
        pageTitle: 'Your Cart',
        products: cartProducts // Pass products in the cart to render
      });
    });
  });
};

// Add a product to the cart
exports.postCart = (req, res, next) => {
  const prodId = req.body.productId;
  Product.findById(prodId, product => {
    Cart.addProduct(prodId, product.price); // Add the product to the cart
  });
  res.redirect('/cart'); // Redirect to the cart page
};

// Delete a product from the cart
exports.postCartDeleteProduct = (req, res, next) => {
  const prodId = req.body.productId;
  Product.findById(prodId, product => {
    Cart.deleteProduct(prodId, product.price); // Delete the product from the cart
    res.redirect('/cart'); // Redirect to the cart page
  });
};

// Render the 'Orders' page
exports.getOrders = (req, res, next) => {
  res.render('shop/orders', {
    path: '/orders',
    pageTitle: 'Your Orders'
  });
};

// Render the 'Checkout' page
exports.getCheckout = (req, res, next) => {
  res.render('shop/checkout', {
    path: '/checkout',
    pageTitle: 'Checkout'
  });
};
