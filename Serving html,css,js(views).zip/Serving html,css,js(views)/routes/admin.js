// Importing required modules

const express= require('express');
const router= express.Router();

const path= require('path');
const rootDir= require('../util/path');

router.get('/add-products', (req, res, next) => { // Handling GET requests to the '/add-products' path
    // res.sendFile(path.join(__dirname, '../', 'views', 'add-product.html'));
    res.sendFile(path.join(rootDir, 'views', 'add-product.html')); // Sending add-product.html form   
});

router.post('/add-product', (req, res, next) => { // Handling POST requests to the '/add-product' path
    console.log(req.body);
    res.redirect('/');  // Redirecting to the root path ('/') after processing the form submission
});

module.exports= router;