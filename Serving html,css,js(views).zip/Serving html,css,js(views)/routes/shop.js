const express= require('express'); // Importing Express.js

const router= express.Router(); // Creating an Express router

const path= require('path'); // Importing the path module 
const rootDir= require('../util/path'); // Importing a custom module to get the root directory

router.get('/', (req, res, next) => { // GET requests to the root path ('/')
    res.sendFile(path.join(rootDir, 'views', 'shop.html')); //  Sending the 'shop.html' file in response
});

router.get('/contact_us', (req, res, next) => {  // Route for contact us page
    res.sendFile(path.join(rootDir, 'views', 'contactUs.html'));  // Sending conatctus.html form   
});

router.post('/success', (req, res, next) => { //  Handling POST requests to the '/success' path
    console.log(req.body);
    res.sendFile(path.join(rootDir, 'views','success.html'));  // Sending html form   
});

module.exports =router;