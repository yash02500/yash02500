const express = require('express');
const bookController = require('../controllers/bookController');

const router = express.Router();

// Book submission
router.post('/submit', bookController.submitBook);

// Get all books
router.get('/all', bookController.getAllBooks);

// Handle book return
router.put('/return/:bookId', bookController.returnBook);

module.exports = router;
