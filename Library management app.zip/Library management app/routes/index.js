const express = require('express');
const router = express.Router();
const bookRoutes = require('./bookRoutes'); // Import your book routes

// Use the book routes
router.use('/books', bookRoutes);

// Define routes for your app
router.get('/', (req, res) => {
  res.sendFile('index.html', { root: 'views' });
});

module.exports = router;
