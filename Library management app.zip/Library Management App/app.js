const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const sequelize= require('./util/database');

const app = express();

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Body parser middleware to handle POST requests
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Set up routes
const routes = require('./routes/index'); 
app.use('/', routes);

// Handle 404 errors
app.use((req, res, next) => {
  res.status(404).send('404: Not Found');
});

// Handle server errors
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('500: Internal Server Error');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
