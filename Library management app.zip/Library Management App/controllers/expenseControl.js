// controllers/userControl.js
const Expense = require('../models/expense');

const expenseController = {
  insertExpense: (req, res) => {
    const { amount, description, expCategory } = req.body;

    Expense.create({ amount, description, expCategory })
      .then(expense => {
        res.status(201).json(expense);
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },

  getExpenses: (req, res) => {
    Expense.findAll()
      .then(expenses => {
        res.json(expenses);
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },

  deleteExpense: (req, res) => {
    const expenseId = req.params.id;

    Expense.destroy({
      where: {
        id: expenseId,
      },
    })
      .then(() => {
        res.json({ message: 'Expense deleted successfully' });
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },

  editExpense: (req, res) => {
    const expenseId = req.params.id;
    const { amount, description, expCategory } = req.body;

    Expense.findByPk(expenseId)
      .then(expense => {
        if (!expense) {
          res.status(404).json({ error: 'Expense not found' });
        } else {
          // Update the expense data
          expense.amount = amount;
          expense.description = description;
          expense.expCategory = expCategory;
          return expense.save();
        }
      })
      .then(updatedExpense => {
        res.json(updatedExpense);
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },
};

module.exports = expenseController;
