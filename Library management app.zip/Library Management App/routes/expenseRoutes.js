const express = require('express');
const expenseController = require('../controllers/expenseControl');

const router = express.Router();

//routes for expense-related endpoints
router.post('/expenses', expenseController.insertExpense);
router.get('/expenses', expenseController.getExpenses);
router.put('/expenses/:id', expenseController.editExpense); 
router.delete('/expenses/:id', expenseController.deleteExpense);

module.exports = router;
