// Required modules
const path = require('path'); // Module for handling file paths
const express = require('express'); // Web framework for Node.js
const bodyParser = require('body-parser'); // Middleware to parse incoming request bodies

// Import db
const sequelize= require('./util/database');

// Initialize express app
const app = express(); // Creating an instance of Express

// Routes
const userRoute = require('./routes/userRoutes'); // Importing admin routes

// Middleware
 app.use(bodyParser.urlencoded({ extended: false })); // Parsing URL-encoded bodies
 app.use(express.static(path.join(__dirname, 'public'))); // Serving static files
//app.use(bodyParser.json());


// Routing
app.use('/admin', userRoute); // Mounting admin routes

// Connect to the database
sequelize.sync()
.then(result=> {
    console.log(result);
})
.catch(err=> {
    console.log(err); // Server listens on port 3000
});

app.listen(3000);

 