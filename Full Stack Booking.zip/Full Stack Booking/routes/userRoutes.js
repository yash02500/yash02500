const express = require('express');
const userController = require('../controllers/userControl');

const router = express.Router();

// Define routes for user-related endpoints
router.post('/users', userController.insertUser);
router.get('/users', userController.getUsers);
router.delete('/users/:id', userController.deleteUser);
router.put('/users/:id', userController.updateUser);

module.exports = router;
