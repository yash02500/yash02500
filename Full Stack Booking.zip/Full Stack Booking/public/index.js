// Import Axios
const axios = require('axios');

// Function to submit the form data
async function submitForm() {
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;

  try {
    // If there is a selectedUserId, update the user
    if (selectedUserId) {
      await axios.put(`/admin/users/${selectedUserId}`, { name, email });
      selectedUserId = null; // Clear the selectedUserId after updating
    } else {
      // Otherwise, add a new user
      await axios.post('/admin/users', { name, email });
    }

    // Clear the form
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';

    // Fetch and display the updated user list
    getUsers();
  } catch (error) {
    console.error(error);
  }
}

// Function to get all users and display them in the table
async function getUsers() {
  try {
    const response = await axios.get('/admin/users');
    const userList = document.getElementById('user-list');

    // Clear existing data
    userList.innerHTML = '';

    // Display the users in the table
    response.data.forEach(user => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>
          <button onclick="deleteUser(${user.id})">Delete</button>
          <button onclick="editUser(${user.id})">Edit</button>
        </td>
      `;
      userList.appendChild(row);
    });
  } catch (error) {
    console.error(error);
  }
}

// Function to delete a user
async function deleteUser(userId) {
  try {
    await axios.delete(`/admin/users/${userId}`);
    getUsers();
  } catch (error) {
    console.error(error);
  }
}

// Function to edit a user
async function editUser(userId) {
  try {
    const response = await axios.get(`/admin/users/${userId}`);
    const user = response.data;

    // Populate the form with the user's data
    document.getElementById('name').value = user.name;
    document.getElementById('email').value = user.email;

    // Set the selectedUserId for update
    selectedUserId = userId;
  } catch (error) {
    console.error(error);
  }
}

// Variable to store the selected user's ID
let selectedUserId = null;

// Initial load of users
getUsers();
