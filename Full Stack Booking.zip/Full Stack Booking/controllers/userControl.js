const User = require('../models/user');

const userController = {
  // Controller function to insert a user
  insertUser: (req, res) => {
    const { name, email } = req.body;

    User.create({ name, email })
      .then(user => {
        res.status(201).json(user);
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },

  // Controller function to get all users
  getUsers: (req, res) => {
    User.findAll()
      .then(users => {
        res.json(users);
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },

  // Controller function to delete a user
  deleteUser: (req, res) => {
    const userId = req.params.id;

    User.destroy({
      where: {
        id: userId,
      },
    })
      .then(() => {
        res.json({ message: 'User deleted successfully' });
      })
      .catch(error => {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
      });
  },

// Controller function to update a user
updateUser: (req, res) => {
  const userId = req.params.id;
  const { name, email } = req.body;

  User.findByPk(userId)
    .then(user => {
      if (!user) {
        res.status(404).json({ error: 'User not found' });
      } else {
        // Update user information
        user.name = name;
        user.email = email;
        return user.save();
      }
    })
    .then(updatedUser => {
      res.json(updatedUser);
    })
    .catch(error => {
      console.error(error);
      res.status(500).json({ error: 'Server Error' });
    });
},


};

module.exports = userController;
