const Product = require('../models/product'); // Importing the Product model

// Render the 'Add Product' page
exports.getAddProduct = (req, res, next) => {
  res.render('add-product', {
    pageTitle: 'Add Product',
    path: '/admin/add-product',
    formsCSS: true,
    productCSS: true,
    activeAddProduct: true
  });
};

// Handing the addition of a new product
exports.postAddProduct = (req, res, next) => {
  const product = new Product(req.body.title); // Create a new Product instance
  product.save(); // Save the product
  res.redirect('/'); // Redirect to the homepage
};

// Render the 'Shop' page with products
exports.getProducts = (req, res, next) => {
  Product.fetchAll(products => {
    res.render('shop', {
      prods: products, // Passing fetched products to render
      pageTitle: 'Shop',
      path: '/',
      hasProducts: products.length > 0, // Set boolean based on product existence
      activeShop: true,
      productCSS: true
    });
  });
};
