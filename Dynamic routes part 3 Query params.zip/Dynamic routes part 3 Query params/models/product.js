const fs = require('fs'); 
const path = require('path');
const Cart = require('./cart'); // Importing Cart model

const p = path.join( // Creating the path to the products.json file
  path.dirname(process.mainModule.filename), 
  'data',
  'products.json'
);

const getProductsFromFile = cb => {
  fs.readFile(p, (err, fileContent) => {
    if (err) {
      cb([]); // Callback with an empty array if there's an error reading the file
    } else {
      cb(JSON.parse(fileContent)); // Callback with the parsed file content
    }
  });
};

module.exports = class Product {
  constructor(id, title, imageUrl, description, price) {
    this.id = id;
    this.title = title;
    this.imageUrl = imageUrl;
    this.description = description;
    this.price = price;
  }

  save() {
    getProductsFromFile(products => {
      if (this.id) {
        const existingProductIndex = products.findIndex(prod => prod.id === this.id);
        const updatedProducts = [...products];
        updatedProducts[existingProductIndex] = this;
        fs.writeFile(p, JSON.stringify(updatedProducts), err => {
          console.log(err); // Log any errors
        });
      } else {
        this.id = Math.random().toString(); // Generating a random ID for a new product
        products.push(this); // Adding the new product to the products array
        fs.writeFile(p, JSON.stringify(products), err => {
          console.log(err); // Log any errors
        });
      }
    });
  }

  static deleteById(id) {
    getProductsFromFile(products => {
      const product = products.find(prod => prod.id === id);
      const updatedProducts = products.filter(prod => prod.id !== id);
      fs.writeFile(p, JSON.stringify(updatedProducts), err => {
        if (!err) {
          Cart.deleteProduct(id, product.price); // Update the cart by deleting the product
        }
      });
    });
  }

  static fetchAll(cb) {
    getProductsFromFile(cb); // Retrieve all products and callback with them
  }

  static findById(id, cb) {
    getProductsFromFile(products => {
      const product = products.find(p => p.id === id);
      cb(product); // Callback with the found product
    });
  }
};
